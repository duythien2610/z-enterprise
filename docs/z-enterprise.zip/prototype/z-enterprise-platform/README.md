# Z-Enterprise Management Platform — Product Prototype

> **Executable Prototype for PRD v1.2-FINAL**  
> Tuân thủ chuẩn mực **BA Product Prototype Operating Model**: Bám sát 100% tài liệu đặc tả [`ISC_ZEnterprise_PRD_Standard_v1.0.md`](file:///c:/BA/ba-tool-kit/project/z-enterprise/output/ISC_ZEnterprise_PRD_Standard_v1.0.md), giao diện chuẩn Enterprise B2B SaaS, không tự phát minh tính năng và tương tác trung thực với mọi Business Rules.

---

## 1. CÁCH KHỞI CHẠY PROTOTYPE

Prototype là một ứng dụng Web tương tác độc lập (Self-contained Interactive Web Application), không yêu cầu cài đặt cơ sở dữ liệu hay backend phức tạp.

### Cách 1: Mở trực tiếp trong trình duyệt
Chỉ cần nhấp đúp chuột (hoặc kéo thả) tệp:
```text
c:\BA\ba-tool-kit\project\z-enterprise\prototype\z-enterprise-platform\index.html
```
vào bất kỳ trình duyệt hiện đại nào (Microsoft Edge, Google Chrome, Firefox, Safari).

### Cách 2: Chạy qua Local HTTP Server (Khuyến nghị)
Trong PowerShell tại thư mục này:
```powershell
python -m http.server 8080
# Hoặc: npx serve -l 8080 .
```
Sau đó truy cập: `http://localhost:8080` trên trình duyệt.

---

## 2. TÍNH NĂNG ĐIỀU HƯỚNG & CHUYỂN ĐỔI VAI TRÒ (PERSONA SWITCHER)

Thanh công cụ phía trên cùng (Top Banner) cho phép bạn chuyển đổi nhanh giữa **5 Persona chuẩn** để kiểm thử mọi góc nhìn thẩm quyền trong RBAC Matrix:

1. 🏢 **Super Admin (HQ)**: Quản trị Quota toàn quốc, cây tổ chức, khởi tạo lệnh Break-Glass Audit và duyệt điều chuyển liên vùng.
2. 🌐 **Region Admin (Vùng TP.HCM)**: Phân bổ Quota cho các chi nhánh trực thuộc, thực hiện Cưỡng chế Thu hồi Quota nhàn rỗi (Pull Model), duyệt điều chuyển Sales nội vùng.
3. 🏪 **Branch Admin (Chi nhánh HCM01 - Tân Bình)**: Cấp tài khoản tự chủ bằng Email công ty `@fpt.com.vn`, Tạm khóa / Mở khóa tài khoản Sales, Giám sát mức 1-2-3 & Cảnh báo SLA (>48h), thực hiện Offboarding cưỡng chế và Bàn giao danh bạ kèm Bot chào tự động.
4. 💼 **Sales Representative (Nguyễn Văn A)**: Không gian làm việc của Sales — Kiểm tra phiên 2 thiết bị (Laptop + Mobile) & cơ chế đẩy FIFO khi vào thiết bị 3, Danh bạ khách hàng chuẩn *Zero Personal Contacts* (SĐT che số `090****567`), Khung chat gửi báo giá PDF 2.4MB, và Gọi thoại 1-1 qua Zalo Enterprise có ghi nhận Metadata.
5. ⚖️ **Legal / Internal Audit (Ban Pháp chế & Kiểm soát)**: Tiếp nhận yêu cầu mở khóa Break-Glass khẩn cấp vụ việc lộ bí mật kinh doanh, kiểm tra hồ sơ và thực hiện Xác thực kép (Dual-Authorization) với chữ ký số/OTP.

---

## 3. HƯỚNG DẪN THỰC THI 7 DEMO JOURNEYS NGHIỆP VỤ

### 🎯 Journey 1: Cưỡng Chế Thu Hồi Quota Nhàn Rỗi (Pull Model - US02, FR01)
1. Chọn vai trò **Region Admin (Vùng TP.HCM)**.
2. Vào mục **Quản trị Hạn ngạch (Quota Governance)**.
3. Quan sát chi nhánh **HCM02 (Phú Nhuận)** đang có 10 Quota tự do chưa gán.
4. Bấm nút **"Cưỡng chế thu hồi (Pull)"** trên dòng HCM02.
5. Thử nhập số lượng:
   - Nếu nhập `15`: Hệ thống lập tức chặn theo `AC-02.2.01` (vượt quá số dư tự do).
   - Nếu nhập `5`: Nhập lý do "Điều tiết hạn ngạch về Vùng", bấm **"Xác nhận Thu hồi"**.
   - Quan sát: Số dư Pool HCM02 giảm từ 10 xuống 5, Region Pool tăng thêm 5 Quota ngay lập tức mà không cần Branch HCM02 duyệt.

### 🎯 Journey 2: Cấp Tài Khoản Tự Chủ & Quản Trị Vòng Đời (US03, US03b, FR02, FR03)
1. Chuyển sang vai trò **Branch Admin (HCM01)**.
2. Tại mục **Nhân sự & Tài khoản**, bấm **"Cấp tài khoản mới"**.
3. Nhập Mã nhân viên `NV1089`, Email `quangnh@fpt.com.vn`.
4. Bấm **"Khởi tạo & Cấp Quota"** -> Branch Pool giảm 1, tài khoản chuyển sang `INVITED_PENDING` kèm đồng hồ đếm ngược 72h.
5. Trên dòng nhân sự `Lê Văn C (Active)`, bấm menu hành động chọn **"Tạm khóa (Suspend)"**.
6. Nhập lý do (dưới 10 ký tự sẽ bị chặn theo `AC-03b.2.01`); nhập lý do đầy đủ và xác nhận -> Trạng thái đổi sang `SUSPENDED`, hiển thị thông báo đã cưỡng chế ngắt toàn bộ phiên làm việc của Sales.
7. Thử bấm **"Mở khóa (Reactivate)"** -> Nhập lý do xác minh để đưa tài khoản trở lại `ACTIVE`.

### 🎯 Journey 3: Không Gian Làm Việc Sales & Gọi Thoại Zalo (US04, US05, FR04, FR05)
1. Chuyển sang vai trò **Sales (Nguyễn Văn A)**.
2. Quan sát thanh trạng thái thiết bị: Đang có 02 thiết bị hoạt động (Laptop Dell Latitude + Mobile iPhone 14).
3. Bấm nút **"Giả lập đăng nhập Thiết bị thứ 3 (iPad Pro)"** -> Hệ thống hiển thị thông báo đẩy phiên cũ nhất (FIFO Eviction) theo `AC-04.3.01`: Phiên Laptop tự động bị đăng xuất.
4. Quan sát Danh bạ khách hàng: 100% là tài sản công ty, không có nhãn cá nhân (`DEC-PO-01`), SĐT khách hàng đều được che 4 số giữa `090****567` (`NFR-05`).
5. Tại khung chat, bấm **"Gửi Báo Giá PDF"** (hợp đồng mẫu 2.4MB) -> Tin nhắn gửi tức thì.
6. Bấm nút **"Gọi thoại Zalo"** -> Modal cuộc gọi 1-1 Zalo kết nối trực tiếp đến khách hàng; bấm kết thúc -> Hệ thống ghi nhận thời lượng cuộc gọi vào Metadata. Có nút chọn thử kịch bản "Khách bận / Cuộc gọi nhỡ" (`AC-05.2.01`) để xem cách hệ thống ghi nhận thời lượng 0s.

### 🎯 Journey 4: Giám Sát Chi Nhánh & Cảnh Báo Vi Phạm SLA (US06, FR06)
1. Quay lại vai trò **Branch Admin (HCM01)**, chọn tab **Giám sát & Báo cáo SLA**.
2. Quan sát 3 cấp độ: Level 1 (Trạng thái), Level 2 (Danh bạ), Level 3 (Metadata: lần nhắn cuối, avg response time).
3. Đọc Banner bảo mật màu xám: **Cấm đọc trộm nội dung chat thường nhật** (Khóa Level 5 theo `DEC-PO-02`).
4. Khách hàng "Anh Hoàng Long - CTCP Xây Dựng Hải Nam" đang bị gắn cờ đỏ **`⚠️ SLA Breach (>48h)`** do gửi câu hỏi báo giá 50 tiếng trước mà chưa được phản hồi.
5. Bấm nút **"Gửi cảnh báo nhắc nhở"** -> Hệ thống gửi push notification tức thì đến app của Sales phụ trách.

### 🎯 Journey 5: Offboarding Cưỡng Chế & Bot Chào Tự Động (US07, US08, FR07)
1. Tại danh sách nhân sự của **Branch Admin (HCM01)**, tìm Sales `Phạm Văn D` (Nghỉ việc, nắm 150 khách hàng).
2. Bấm nút **"Offboarding & Bàn giao"**.
3. Chọn Sales kế nhiệm là `Nguyễn Văn E`.
4. Bấm **"Xác nhận Bàn giao & Gửi tin nhắn chào khách"**.
5. Quan sát:
   - Toàn bộ 150 khách chuyển giao sang Nguyễn Văn E (không chuyển lịch sử chat cũ).
   - Thanh tiến độ Bot Message Queue đếm động theo tốc độ điều tiết 5 tin/giây chống Spam Zalo (`Đã gửi: 150/150`).
   - Tài khoản của Sales D chuyển vĩnh viễn sang `ARCHIVED_AND_REVOKED` (chống tái sử dụng).
   - **Branch Pool lập tức được cộng lại +1 Quota tự do**!
6. Bấm nút **"Giả lập Khách nhắn tin vào tài khoản cũ"** -> Modal mô phỏng màn hình Zalo của khách hàng: Tin nhắn bị chặn kèm thông báo chuẩn: *"Người nhận hiện không thể tiếp nhận tin nhắn vào thời điểm này"* (`AC-08.1.01`).

### 🎯 Journey 6: Điều Chuyển Sales Liên Chi Nhánh (US09, FR09)
1. Trong danh sách nhân sự, tìm Sales `Trần Văn F`.
2. Bấm nút **"Điều chuyển chi nhánh"** sang HCM02.
3. Thử bấm "Xác nhận chuyển ngay" -> Hệ thống lập tức BÁO LỖI theo `AC-09.2.01`: Sales vẫn còn 45 khách hàng tại chỗ, bắt buộc phải bàn giao 100% tại chi nhánh cũ trước khi đi!
4. Bấm **"Bàn giao 45 khách tại chỗ cho Sales nội bộ"** -> Danh bạ về 0.
5. Chuyển sang vai trò **Region Admin**, tại mục Duyệt điều chuyển, bấm **"Phê duyệt Điều chuyển"** -> 1 Quota chuyển từ Pool HCM01 sang Pool HCM02; Sales F hoạt động tại HCM02 với danh bạ mới tinh!

### 🎯 Journey 7: Mở Khóa Kiểm Toán Khẩn Cấp (Break-Glass - US10, FR08)
1. Chuyển sang vai trò **Super Admin (HQ)**, vào tab **Mở khóa Khẩn cấp (Break-Glass Audit)**.
2. Bấm **"Tạo yêu cầu Mở khóa Kiểm toán"**.
3. Nhập Mã vụ việc: `FTEL-INV-2026-09`, chọn tài khoản điều tra `hoangvg@fpt.com.vn`, nhập lý do nghi vấn lộ giá thầu.
4. Ký số Bước 1 -> Yêu cầu chuyển sang trạng thái `PENDING_LEGAL_APPROVAL`.
5. Thử bấm "Xem dữ liệu ngay" -> Bị CHẶN theo `AC-10.2.01` (Thiếu chữ ký kép từ Pháp chế).
6. Đổi vai trò sang **Legal / Internal Audit (Ban Pháp chế)**.
7. Xem chi tiết hồ sơ điều tra, nhập Mã OTP Pháp chế `886921` và bấm **"Đồng Phê Duyệt Kép"**.
8. Kết quả: Phát tín hiệu **Security Red Alert** đến Hội đồng An ninh mạng FPT (CSOC), mở trình duyệt trích xuất nội dung tin nhắn phục vụ điều tra kèm đồng hồ đếm ngược hiệu lực 24 giờ.

---

## 4. TÀI LIỆU LIÊN QUAN

- [Bản Đặc Tả PRD Chuẩn FPT ISC (v1.2-FINAL)](file:///c:/BA/ba-tool-kit/project/z-enterprise/output/ISC_ZEnterprise_PRD_Standard_v1.0.md)
- [Báo Cáo Quality Audit 6 Lăng Kính (v1.1)](file:///c:/BA/ba-tool-kit/project/z-enterprise/output/ISC_ZEnterprise_PRD_v1.1_Quality_Audit_Report.md)
- [Prototype Scope Contract](file:///c:/BA/ba-tool-kit/project/z-enterprise/prototype/z-enterprise-platform/PROTOTYPE_SCOPE.md)
- [Prototype Requirements Traceability Matrix (RTM)](file:///c:/BA/ba-tool-kit/project/z-enterprise/prototype/z-enterprise-platform/PROTOTYPE_TRACEABILITY.md)
- [Prototype Quality Review Report](file:///c:/BA/ba-tool-kit/project/z-enterprise/prototype/z-enterprise-platform/PROTOTYPE_REVIEW.md)

